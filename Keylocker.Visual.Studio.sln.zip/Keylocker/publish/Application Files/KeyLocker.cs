﻿using System;
using System.IO;
using System.Text;
using System.Drawing;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace Keylocker
{
    ///<summary>
    ///This program creates unique codes, for example for locks.
    ///Raymond Moesker
    ///</summary>
    class KeyLocker
    {
        static void Main(string[] args)
        {
            Console.Clear();
            string path = "keys.txt";
            if (!File.Exists(path))
            {
                try
                {
                    // Create the file.
                    using (FileStream fs = File.Create(path))
                    {
                        Byte[] info = new UTF8Encoding(true).GetBytes("Keys; Date;Time:" + Environment.NewLine);
                        // Add some information to the file.
                        fs.Write(info, 0, info.Length);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }
            DateTime dat = DateTime.Now;
            int randomnumber = KeyLocker.GetRandomNumber();
            System.Console.WriteLine("Your Random number is:" + randomnumber);
            
            try
            {
                using (StreamWriter sw = File.AppendText(path))
                {
                    sw.WriteLine(randomnumber + ";{0:d};{0:T}", dat);
                }
                Console.WriteLine("\nArchived: " + randomnumber + ";{0:d};{0:T}", dat);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

            Console.Write("Do you want to print the key? [Y or N]");
            var print = Console.ReadLine();
            if (print.Equals("N") || print.Equals("n"))
            {
                Console.Write("\nPress any key to continue... ");
                Console.ReadLine();
            }
            else if (print.Equals("Y") || print.Equals("y"))
            {
                try
                {
                    PrintDialog printDialog = new PrintDialog();
                    PrintDocument printDocument = new PrintDocument();
                    printDialog.Document = printDocument;
                    printDocument.PrintPage += delegate (object sender1, PrintPageEventArgs e1)
                    {
                        e1.Graphics.DrawString(" " + randomnumber, new Font("Times New Roman", 12), new SolidBrush(Color.Black), new RectangleF(0, 0, printDocument.DefaultPageSettings.PrintableArea.Width, printDocument.DefaultPageSettings.PrintableArea.Height));
                    };
   
                    DialogResult result = printDialog.ShowDialog();

                    if (result == DialogResult.OK)
                    {
                        printDocument.Print();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                Console.Write("\nDone Printing.. ");
                Console.ReadLine();
            }
            else
            {
                Console.Write("\n Wrong input.\nPress any key to continue... ");
                Console.ReadLine();
            }
        }
        // The PrintDialog will print the document
        // by handling the document's PrintPage event.
        private void document_PrintPage(object sender,
            System.Drawing.Printing.PrintPageEventArgs e)
        {

            // Insert code to render the page here.
            // This code will be called when the control is drawn.

            // The following code will render a simple
            // message on the printed document.
            string text = "In document_PrintPage method.";
            System.Drawing.Font printFont = new System.Drawing.Font
                ("Arial", 35, System.Drawing.FontStyle.Regular);

            // Draw the content.
            e.Graphics.DrawString(text, printFont,
                System.Drawing.Brushes.Black, 10, 10);
        }
        // Return 4 digit random nuimber.
        public static int GetRandomNumber()
        {
            int min = 1000;
            int max = 9999;
            Random rdm = new Random();
            return rdm.Next(min, max);
        }
    }
}
